using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Popout : MonoBehaviour
{
    [Header("Popout")]
    [SerializeField] private GameObject popout;

    private bool playerInRange;

    private void Awake()
    {
        playerInRange = false;
        popout.SetActive(false);
    }

    private void Update()
    {
        if (playerInRange)
        {
            popout.SetActive(true);
        }
        else{
            popout.SetActive(false);
        }
    }

    private void OnTriggerEnter2D(Collider2D collider)
    {
        if (collider.gameObject.tag == "Player")
        {
            playerInRange = true;
        }
    }

    private void OnTriggerExit2D(Collider2D collider)
    {
        if (collider.gameObject.tag == "Player")
        {
            playerInRange = false;
        }
    }

    
}
