using UnityEngine;
using UnityEngine.SceneManagement;

public class Finishline : MonoBehaviour
{
    [Header("EndMenu")]
    [SerializeField] private GameObject endMenu;

    [Header("Audio")]
    [SerializeField] private AudioClip finishSfx;

    private AudioSource audioSource;

    private void Start()
    {
        // Get AudioSource component
        audioSource = GetComponent<AudioSource>();
        if (audioSource == null)
        {
            // If no AudioSource is attached, add one dynamically
            audioSource = gameObject.AddComponent<AudioSource>();
        }
    }

    //Show End Panel
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("Player"))
        {
            endMenu.SetActive(true);
            Time.timeScale = 0;
            audioSource.PlayOneShot(finishSfx);
        }
    }

    //Send back2menu
    public void Home()
    {
        SceneManager.LoadScene(0);
        Time.timeScale = 1;
    }

    //Retry the Stage
    public void Retry()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
        Time.timeScale = 1;
    }
}
