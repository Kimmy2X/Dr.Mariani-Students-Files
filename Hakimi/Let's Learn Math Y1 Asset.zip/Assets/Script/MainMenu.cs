using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class MainMenu : MonoBehaviour
{
    [Header("SettingMenu")]
    [SerializeField] private GameObject settingMenu;

    public void Setting()
    {
        settingMenu.SetActive(true);
    }

    public void QuitGame()
    {
        Application.Quit();
    }
}
