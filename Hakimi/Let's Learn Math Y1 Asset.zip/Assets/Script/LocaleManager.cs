using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Localization.Settings;

public class LocaleManager : MonoBehaviour
{
    //prevent corountine from being press many times
    private bool active = false;

    public void changeLanguage(int localeID)
    {
        if (active == true)
            return;
        StartCoroutine(setLanguage(localeID));
    }

    IEnumerator setLanguage(int _localeID)
    {
        active = true;

        // Wait for the localization system to initialize, loading Locales, preloading, etc.
        yield return LocalizationSettings.InitializationOperation;

        // This change the language
        LocalizationSettings.SelectedLocale = LocalizationSettings.AvailableLocales.Locales[_localeID];

        active = false;
    }
}
