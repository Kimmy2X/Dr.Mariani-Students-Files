using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    private float horizontal;
    private float speed = 5f;
    private float jumpingPower = 10f;
    private bool isFacingRight = true;

    // Mobile-specific variables for movement and jumping
    private bool moveLeft = false;
    private bool moveRight = false;
    private bool jumpPressed = false;

    private bool _isMoving = false;
    private bool _isJumping = false;

    public bool isMoving
    {
        get { return _isMoving; }
        private set
        {
            _isMoving = value;
            animator.SetBool("isMoving", value); // Update the "isMoving" in the Animator
        }
    }

    public bool isJumping
    {
        get { return _isJumping; }
        private set
        {
            _isJumping = value;
            animator.SetBool("isJumping", value); // Update the "isJumping" in the Animator
        }
    }

    [SerializeField] private Animator animator;
    [SerializeField] private Rigidbody2D rb;
    [SerializeField] private Transform groundCheck;
    [SerializeField] private LayerMask groundLayer;

    void Update()
    {
        // PC Input for horizontal movement
        horizontal = Input.GetAxisRaw("Horizontal");

        // Mobile Input for horizontal movement
        if (moveLeft)
        {
            horizontal = -1f;
        }
        else if (moveRight)
        {
            horizontal = 1f;
        }

        // PC Jump Input
        if (Input.GetButtonDown("Jump") && IsGrounded())
        {
            jumpPressed = true;
        }

        // Mobile Jump Input
        if (jumpPressed && IsGrounded())
        {
            rb.velocity = new Vector2(rb.velocity.x, jumpingPower);
            isJumping = true;  // Set isJumping to true when jump starts
            jumpPressed = false; // Reset after jumping
        }

        // Update jump animation
        if (IsGrounded() && rb.velocity.y <= 0f)
        {
            isJumping = false;  // Set isJumping to false only when the character has landed
        }

        Flip();
    }

    void FixedUpdate()
    {
        // Apply horizontal movement
        rb.velocity = new Vector2(horizontal * speed, rb.velocity.y);

        // Update walk animation
        isMoving = Mathf.Abs(horizontal) > 0.01f;  // True if horizontal movement is significant
    }

    private bool IsGrounded()
    {
        return Physics2D.OverlapCircle(groundCheck.position, 0.5f, groundLayer);
    }

    private void Flip()
    {
        if (isFacingRight && horizontal < 0f || !isFacingRight && horizontal > 0f)
        {
            isFacingRight = !isFacingRight;
            Vector3 localScale = transform.localScale;
            localScale.x *= -1f;
            transform.localScale = localScale;
        }
    }

    // Mobile-specific functions for holding buttons
    public void OnMoveLeftDown()
    {
        moveLeft = true;
    }

    public void OnMoveLeftUp()
    {
        moveLeft = false;
    }

    public void OnMoveRightDown()
    {
        moveRight = true;
    }

    public void OnMoveRightUp()
    {
        moveRight = false;
    }

    public void OnJumpButtonDown()
    {
        jumpPressed = true;
    }
}
