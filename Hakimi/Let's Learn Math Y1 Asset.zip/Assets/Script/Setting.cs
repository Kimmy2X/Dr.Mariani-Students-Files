using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class Setting : MonoBehaviour
{
    [Header("PauseMenu")]
    [SerializeField] GameObject settingMenu;

    public void openSettingPanel()
    {
        settingMenu.SetActive(true);
        Time.timeScale = 0;
    }

    public void closeSettingPanel()
    {
        settingMenu.SetActive(false);
        Time.timeScale = 1;
    }
}
