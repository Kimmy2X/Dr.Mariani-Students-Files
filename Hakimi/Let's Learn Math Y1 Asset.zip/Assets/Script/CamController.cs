using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CamControl : MonoBehaviour
{
    Transform target;
    Vector3 velocity = Vector3.zero;

    //Camera follow sens
    [Range(0, 1)]
    public float smoothTime;

    public Vector3 positionOffset;

    private void Awake()
    {
        target = GameObject.FindGameObjectWithTag("Player").transform;
    }

    //Motion of the Camera
    private void LateUpdate()
    {
        // Calculate the target position with the offset
        Vector3 targetPosition = target.position + positionOffset;

        // Keep x axis fixed
        targetPosition.y = 0;

        // Smoothly move the camera to the new position
        transform.position = Vector3.SmoothDamp(transform.position, targetPosition, ref velocity, smoothTime);
    }
}
