using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class LevelSelection : MonoBehaviour
{
    //Open lvl depend on the id
    public void OpenLevel(int levelID)
    {
        SceneManager.LoadScene(levelID);
    }
}
