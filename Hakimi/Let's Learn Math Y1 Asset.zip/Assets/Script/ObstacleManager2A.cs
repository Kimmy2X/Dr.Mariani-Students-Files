using UnityEngine;
using TMPro;

public class ObstacleManager2A : MonoBehaviour
{
    [Header("First Answer")]
    [SerializeField] private string correctAnswer1 = "Answer";

    [Header("Second Answer")]
    [SerializeField] private string correctAnswer2 = "Answer2";

    [Header("First Input Field")]
    [SerializeField] private TMP_InputField inputField1;

    [Header("Second Input Field")]
    [SerializeField] private TMP_InputField inputField2;

    [Header("Obstacle")]
    [SerializeField] private GameObject obstacle; // The obstacle that will be destroyed

    [Header("Image")]
    [SerializeField] private GameObject correct; // Correct Img
    [SerializeField] private GameObject wrong;   // Wrong Img

    [Header("Audio")]
    [SerializeField] private AudioClip correctSfx; // Correct sfx
    [SerializeField] private AudioClip wrongSfx; // Wrong sfx

    private AudioSource audioSource;

    private void Start()
    {
        // Hide both
        correct.SetActive(false);
        wrong.SetActive(false);

        // Get AudioSource component
        audioSource = GetComponent<AudioSource>();
        if (audioSource == null)
        {
            // If no AudioSource is attached, add one dynamically
            audioSource = gameObject.AddComponent<AudioSource>();
        }
    }

    public void CheckAnswer()
    {
        string userInput1 = inputField1.text.Trim();
        string userInput2 = inputField2.text.Trim();

        Debug.Log($"UserInput1: {userInput1}, CorrectAnswer1: {correctAnswer1}");
        Debug.Log($"UserInput2: {userInput2}, CorrectAnswer2: {correctAnswer2}");

        Debug.Log($"UserInput1: {userInput1}, CorrectAnswer1: {correctAnswer1}");
        Debug.Log($"UserInput2: {userInput2}, CorrectAnswer2: {correctAnswer2}");

        // Compare the player input with the correct answer
        if (userInput1.Equals(correctAnswer1, System.StringComparison.OrdinalIgnoreCase) && userInput2.Equals(correctAnswer2, System.StringComparison.OrdinalIgnoreCase))
        {
            // Show the correct and hide the wrong
            correct.SetActive(true);
            wrong.SetActive(false);

            //Play correct sfx
            audioSource.PlayOneShot(correctSfx);

            // Destroy the obstacle
            Destroy(obstacle);
            Debug.Log("Obstacle Destroyed");
        }
        else
        {
            //Play wrong sfx
            audioSource.PlayOneShot(wrongSfx);

            // Show the wrong and hide the correct
            wrong.SetActive(true);
            correct.SetActive(false);
            Debug.Log("Wrong Answer");
        }
    }
}
