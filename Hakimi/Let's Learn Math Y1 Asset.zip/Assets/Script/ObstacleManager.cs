using UnityEngine;
using TMPro;

public class ObstacleManager : MonoBehaviour
{
    [Header("En Correct Answer")]
    [SerializeField] private string correctAnswer = "Answer"; // The answer in English

    [Header("Bm Correct Answer")]
    [SerializeField] private string correctAnswer2 = "Answer2"; // The answer in Malay

    [Header("UI Elements")]
    [SerializeField] private TMP_InputField inputField; // Input field

    [Header("Obstacle")]
    [SerializeField] private GameObject obstacle; // The obstacle that will be destroyed

    [Header("Image")]
    [SerializeField] private GameObject correct; // Correcr Img
    [SerializeField] private GameObject wrong;   // Wrong Img

    [Header("Audio")]
    [SerializeField] private AudioClip correctSfx; // Correct Sfx
    [SerializeField] private AudioClip wrongSfx; // Wrong Sfx

    private AudioSource audioSource;

    private void Start()
    {
        // Hide both
        correct.SetActive(false);
        wrong.SetActive(false);

        // Get AudioSource component
        audioSource = GetComponent<AudioSource>();
        if (audioSource == null)
        {
            // If no AudioSource is attached, add one dynamically
            audioSource = gameObject.AddComponent<AudioSource>();
        }
    }

    public void CheckAnswer()
    {
        string userInput = inputField.text.Trim();

        // Compare the player input with the correct answer
        if (userInput.Equals(correctAnswer, System.StringComparison.OrdinalIgnoreCase) || userInput.Equals(correctAnswer2, System.StringComparison.OrdinalIgnoreCase))
        {
            // Show the correct and hide the wrong 
            correct.SetActive(true);
            wrong.SetActive(false);

            //Play correct sfx
            audioSource.PlayOneShot(correctSfx);

            // Destroy the obstacle
            Destroy(obstacle);
            Debug.Log("Obstacle Destroyed");
        }
        else
        {
            //Play wrong sfx
            audioSource.PlayOneShot(wrongSfx);
            
            // Show the wrong and hide the correct
            wrong.SetActive(true);
            correct.SetActive(false);
        }
    }
}
